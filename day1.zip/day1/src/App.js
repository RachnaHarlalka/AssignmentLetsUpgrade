import { bold } from 'chalk'
import React from 'react'
import Button from './Button'

function App() {
    return (
        <div className="container">
            <h1>Hello World</h1>
            <p style={{ marginBottom: "30px" }}>Excited to learn React, will definitely master it</p>
            <div className="buttons">
                <Button buttonText="click1" />
                <Button buttonText="click2" />
                <Button buttonText="click3" />

            </div>
        </div>
    )
}

export default App;