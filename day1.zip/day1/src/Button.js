import React from 'react'

const Button = ({ buttonText }) => {
    return (
        <button>{buttonText}</button>
    )
}

export default Button